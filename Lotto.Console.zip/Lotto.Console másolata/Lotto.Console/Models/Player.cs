﻿using System;
using System.Collections.Generic;

namespace Lotto.Console.Models;

public partial class Player
{
    private string _email;
    private int _amount;

    public Player(string name, string email)
    {
        if (string.IsNullOrEmpty(name))
        {
            throw new ArgumentException("Nem lehet üres a név!");
        }
        Name = name;
        if (string.IsNullOrEmpty(email) || !email.Contains('@'))
        {
            throw new ArgumentException("Nem lehet üres, vagy nem megfelelő formátumú az email!");
        }
        _email = email;
        _amount = 0;
    }

    public string Name { get; set; }
    public string Email { get => _email; set => _email = value; }
    public int Amount { get => _amount; set => _amount = value; }

    public bool HasAmount => _amount > 0;

    public void IncreaseAmount(int amount)
    {
        if (amount <= 0)
        {
            throw new InvalidOperationException("Az összeg legalább nagyobb mint nulla!");
        }
        _amount += amount;  
    }

    public void DecreaseAmount(int amount)
    {
        if (amount >= 0)
        {
            throw new InvalidOperationException("Az összeg legalább kisebb mint nulla!");
        }
        _amount += amount;
    }

    public override string ToString()
    {
        return $"Name: {Name}, email: {Email}, összege: {Amount} Ft";
    }
}
