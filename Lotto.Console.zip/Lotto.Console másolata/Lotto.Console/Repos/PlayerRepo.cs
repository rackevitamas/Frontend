﻿using Lotto.Console.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lotto.Console.Repos
{
    public class PlayerRepo
    {
        private readonly PlayersContext _playersContext = new();

        public int GetPlayerOfAmount()
        {
            return _playersContext.Players.Sum(p => p.Amount);
        }

        public List<Player> GetPlayersByAmount()
        {
            return _playersContext.Players.Where(p => p.Amount > 0).ToList();
        }

        public List<Player> GetPlayersByGreaterThanAmount(int amount)
        {
            return _playersContext.Players.Where(p => p.Amount > amount).ToList();
        }
    }
}
