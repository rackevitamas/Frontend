<script setup>
  import { ref, onMounted } from 'vue';
  import { useLottoStore } from '@/stores/lotto';

  const store = useLottoStore();

  onMounted(async () => {
    store.fetchLotto();
  })
</script>

<template>
  <h1 class="text-center">Fogadások</h1>
  <div class="border">
    <div v-if="!store.listOfLotto || store.listOfLotto.length === 0">
      <p class="text-danger d-flex justify-content-center">Még nincs leadott fogadás.</p>
    </div>
    <div v-else>
      <p>Megtett játékok:</p>
      <ul v-for="item in store.listOfLotto">
        <li>{{ item.name }}</li>
      </ul>
      <button class="btn btn-danger" @click="store.deleteAll()">List törlése</button>
    </div>
  </div>
</template>

<style>
</style>