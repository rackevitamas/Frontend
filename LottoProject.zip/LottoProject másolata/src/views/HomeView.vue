<script setup>
  import { ref, onMounted } from 'vue';
  import { useLottoStore } from '@/stores/lotto';

  const store = useLottoStore();
</script>

<template>
  <h1 class="text-center">Lottók</h1>
  <div class="container">
    <div class="row">
      <div class="card col-lg-4 col-md-6 col-sm-12">
        <div class="card-body">
          <h3>Ötöslottó</h3>
          <img src="/public/lotto5.png" alt="">
          <p>Az Ötöslottó játékban 90 számból kel 5-öt kiválasztani.</p>
          <button class="btn btn-success" @click="store.addToLotto('Ötöslottó')">Játsszon</button>
        </div>
      </div>
      <div class="card col-lg-4 col-md-6 col-sm-12">
        <div class="card-body">
          <h3>Hatoslottó</h3>
          <img src="/public/lotto6.png" alt="">
          <p>A Hatoslottó játékban 45 számból kell 6-ot kiválasztani.</p>
          <button class="btn btn-success" @click="store.addToLotto('Hatoslottó')">Játsszon</button>
        </div>
      </div>
      <div class="card col-lg-4 col-md-6 col-sm-12">
        <div class="card-body">
          <h3>Skandináv Lottó</h3>
          <img src="/public/lotto7.png" alt="">
          <p>A Skandináv lottó játékban 35 számból kell 7-et kiválasztani.</p>
          <button class="btn btn-success"  @click="store.addToLotto('Skandináv lottó')">Játsszon</button>
        </div>
      </div>
      <div class="card col-lg-4 col-md-6 col-sm-12">
        <div class="card-body">
          <h3>EuroJackpot</h3>
          <img src="/public/lotto8.png" alt="">
          <p>Az EuroJackpot játékban 50 számból kell 5-öt és 12-ből 2-öt kiválasztani</p>
          <button class="btn btn-success" @click="store.addToLotto('EuroJackpot')">Játsszon</button>
        </div>
      </div>
    </div>
  </div>
</template>

<style>
  img{
    width: 100%;
  }
</style>