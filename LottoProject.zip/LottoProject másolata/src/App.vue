<script setup>
import { RouterLink, RouterView } from 'vue-router'
import HelloWorld from './components/HelloWorld.vue'
</script>

<template>
      <nav class="text-center m-3">
        <RouterLink to="/" class="btn btn-outline-success">Lottók</RouterLink>
        <RouterLink to="/game" class="btn btn-outline-success">Játék</RouterLink>
      </nav>
  <RouterView />
</template>

<style scoped>
</style>
