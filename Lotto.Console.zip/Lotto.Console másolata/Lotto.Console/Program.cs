﻿using Lotto.Console.Repos;

PlayerRepo repo = new PlayerRepo();

Console.WriteLine("A jákékosok összes összege: " + repo.GetPlayerOfAmount() + " Ft");

var list = repo.GetPlayersByAmount();

foreach (var player in list)
{
    Console.WriteLine(player);
}

Console.WriteLine();

var list2 = repo.GetPlayersByGreaterThanAmount(15000);

foreach (var player in list2)
{
    Console.WriteLine(player);
}