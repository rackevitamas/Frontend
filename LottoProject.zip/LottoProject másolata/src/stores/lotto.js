import { ref, computed } from 'vue'
import { defineStore } from 'pinia'
import axios from 'axios'

export const useLottoStore = defineStore('lotto', () => {
  
  const listOfLotto = ref([]);

  axios.get('http://localhost:3000/lotto')
  .then(resp => listOfLotto.value = resp.data);

  const fetchLotto = async () => {
    const resp = await axios.get('http://localhost:3000/lotto');
    listOfLotto.value = resp.data;
  }

  const addToLotto = async (lotto) => {
    const newLotto = {name: lotto};

    await axios.post('http://localhost:3000/lotto', newLotto);

    await fetchLotto();
  }

  const deleteAll = async () => {

    const resp = await axios.get('http://localhost:3000/lotto');
    listOfLotto.value = resp.data;

    for (const item of listOfLotto.value) {
      await axios.delete(`http://localhost:3000/lotto/${item.id}`);
    }

    await fetchLotto();
  }

  return { listOfLotto, fetchLotto, addToLotto, deleteAll }
})
